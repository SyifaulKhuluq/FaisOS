# FaisOS Backend

Backend ringan berbasis FastAPI untuk mengelola informasi sistem dan aplikasi Docker.

## 🔧 Cara Jalankan (Python Lokal)
```bash
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

## 🐳 Cara Jalankan via Docker
```bash
docker-compose up --build -d
```

## 📖 Endpoint API
- `GET /system/info` – Info sistem (CPU, RAM, Disk)
- `GET /apps/list` – List Docker container
- `POST /apps/install` – Install app (via nama dan image Docker)
- `DELETE /apps/uninstall` – Hapus app Docker
- `GET /store/list` – Daftar app dari `appstore.json`