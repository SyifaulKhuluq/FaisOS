from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import psutil
import docker
import json
from pathlib import Path

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

client = docker.from_env()

@app.get("/system/info")
def get_system_info():
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    return {
        "cpu_usage": psutil.cpu_percent(interval=1),
        "ram_total": f"{mem.total / 1e9:.1f} GB",
        "ram_used": f"{mem.used / 1e6:.0f} MB",
        "disk_used": f"{disk.used / 1e9:.1f} GB / {disk.total / 1e9:.1f} GB"
    }

@app.get("/apps/list")
def list_apps():
    containers = client.containers.list(all=True)
    result = []
    for container in containers:
        result.append({
            "name": container.name,
            "status": container.status,
            "image": container.image.tags[0] if container.image.tags else "unknown"
        })
    return result

@app.post("/apps/install")
def install_app(name: str, image: str):
    try:
        container = client.containers.run(image, name=name, detach=True, ports={'80/tcp': None})
        return {"message": f"App {name} installed successfully."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/apps/uninstall")
def uninstall_app(name: str):
    try:
        container = client.containers.get(name)
        container.stop()
        container.remove()
        return {"message": f"App {name} removed successfully."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/store/list")
def get_store_list():
    file_path = Path("data/appstore.json")
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="App store not found.")
    with open(file_path) as f:
        return json.load(f)